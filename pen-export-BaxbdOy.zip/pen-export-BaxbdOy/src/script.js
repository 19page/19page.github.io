$(document).ready(function(){
  <!-- all the following code will be run by jQuery -->
  
   $('#addItemBtn').click(function(){
     
      let itemType = $("#itemType").val(); //get the value from the dropdown list
$("#itemTable").append(
                '<tr>' +
                      '<td>' + itemType + '</td>' +
                      '<td>' + "500$" + '</td>' +
                      
               + '</tr>');
  });
  
});